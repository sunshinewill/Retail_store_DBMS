import csv
import os
import psycopg2
from config import config

table_list = ["Stores.csv", "Suppliers.csv", "Items.csv", "Customers.csv", "Purchases.csv", "Items_sold.csv", "Inventory.csv"]
# table_list = ["Suppliers.csv"]
load_file = ""

dir = os.path.dirname(__file__)

for table in table_list:
    table_name = table.split('.')[0].lower()
    load_file += "delete from {};\n".format(table_name)

for table in table_list:
    table_name = table.split('.')[0].lower()
    table_path = dir + "/Data/" + table
    with open(table_path, 'r') as tbl:
        reader = csv.reader(tbl)
        next(reader)
        for row in reader:
            load_file += "INSERT INTO {} VALUES {};\n".format(table_name, tuple(row))

with open('load.sql', 'w') as f:
    f.write(load_file)

# print(load_file)

conn = None
try:
    # read the connection parameters
    params = config()
    # connect to the PostgreSQL server
    conn = psycopg2.connect(**params)
    cur = conn.cursor()
    with open('load.sql', 'r') as data_in:
        # execute insert one by one
        for query in data_in:
            cur.execute(query)
        # close communication with the PostgreSQL database server
    cur.close()
    # commit the changes
    conn.commit()
except (Exception, psycopg2.DatabaseError) as error:
    print(error)
finally:
    if conn is not None:
        conn.close()
