import psycopg2
from config import config


def create_tables():
    """ create tables in the PostgreSQL database"""
    commands = (

        """
              CREATE TABLE  Stores(
                   Store_ID varchar(10) PRIMARY KEY,
                   Address varchar(150) NOT NULL,
                   Contact_number char(10) NOT NULL--ONLY FOR USA NUMBER WITHOUT COUNTRY CODE
                   --ZipCode varchar(6)
                   )
               """,
        """
        CREATE TABLE Suppliers(
              Supplier_ID varchar(6) PRIMARY KEY,
              Supplier_Name varchar(50) NOT NULL,
              Address varchar(100) NOT NULL,
              Contact_number char(10) NOT NULL
              )
        """,
        """
         CREATE TABLE Items(
              Item_ID varchar(10) PRIMARY KEY,
              Item_Name varchar(50),
              Brand varchar(50),
              Suppliers_ID varchar(6) REFERENCES Suppliers(Supplier_ID),
             -- category varchar(10),
              Unit_Price numeric (10,2) CHECK(Unit_Price > 0)
              --FOREIGN KEY Suppliers_ID REFERENCES Suppliers(Supplier_ID)
        )
        """,

        """
        CREATE TABLE Customers(
            Customer_ID varchar(10) PRIMARY KEY,
            Customer_Name varchar(50) NOT NULL,
            Address varchar(150) NOT NULL,
            Contact_number char(10) NOT NULL,--ONLY FOR USA NUMBER WITHOUT COUNTRY CODE
            Customer_email varchar(40),--  Total_Amount_$ numeric (7,0) NOT NULL DEFAULT 0,
            Total_Orders numeric(5,0) DEFAULT 0,
            prefer_store_id varchar(6) REFERENCES Stores(Store_ID)
            --FOREIGN KEY prefer_store_id REFERENCES Stores(Store_ID)
        )
        """,
        """
        CREATE TABLE Purchases(
              Bill_Number numeric (6,0) PRIMARY KEY,
              Customer_ID varchar(6) REFERENCES Customers(Customer_ID),
              Total_Price_$ numeric (6,2),
              Tax_included_Total numeric (6,2),
              Transction_time time,
              Store_ID varchar(10) REFERENCES Stores(Store_ID)
             -- FOREIGN KEY Customer_ID REFERENCES Customers(Customer_ID),
             --FOREIGN KEY Store_ID REFERENCES Stores(Store_ID)
              -- PRIMARY KEY (Bill_Number);
        )
        """,
        """
        CREATE TABLE Items_sold(
              Item_ID  varchar(6) REFERENCES Items,
              Quantity numeric (4,0) NOT NULL,
              Bill_Number numeric (6,0) REFERENCES Purchases,
             -- Store_ID varchar(10) REFERENCES Stores(Store_ID),
              PRIMARY KEY (Item_ID,Bill_Number)
              --FOREIGN KEY Bill_Number REFERENCES Purchases(Bill_Number),
              --FOREIGN KEY Store_ID REFERENCES Stores(Store_ID)
            )
        """,
        """
        CREATE TABLE Inventory(
              Item_ID varchar(10) REFERENCES Items(Item_ID),
              Store_ID varchar(10) REFERENCES Stores(Store_ID),
              Quantity numeric (14,0) NOT NULL DEFAULT 0,
              PRIMARY KEY (Item_ID,Store_ID)
              --FOREIGN KEY Item_ID REFERENCES Items(Item_ID),
              --FOREIGN KEY Store_ID REFERENCES Stores(Store_ID)
    
            )
        """,

        )
    conn = None
    try:
        # read the connection parameters
        params = config()
        # connect to the PostgreSQL server
        conn = psycopg2.connect(**params)
        cur = conn.cursor()
        # create table one by one
        for command in commands:
            cur.execute(command)
        # close communication with the PostgreSQL database server
        cur.close()
        # commit the changes
        conn.commit()
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
        if conn is not None:
            conn.close()


if __name__ == '__main__':
    create_tables()
